﻿using System;
abstract class Shape
{
    public abstract double Area();
}

class Circle : Shape
{
    private double radius;
    public Circle(double radius)
    {
        this.radius = radius;
    }

    public override double Area()
    {
        return Math.PI * (radius * radius);
    }
}

class rectangle : Shape
{
    private double width;
    private double height;
    public rectangle(double width, double height)
    {
        this.width = width;
        this.height = height;
    }

    public override double Area()
    {
        return width * height;
    }
}

class square : Shape
{
    private double side;
    public square(double side)
    {
        this.side = side;
    }

    public override double Area()
    {
        return side * side;
    }
}

class Triangle : Shape
{
    private double baseLength;
    private double height;
    public Triangle(double baseLength, double height)
    {
        this.baseLength = baseLength;
        this.height = height;
    }

    public override double Area()
    {
        return 0.5 * baseLength * height;
    }
}

class area
{
    static void Main(string[] args)
    {
        Circle circle = new Circle(3);
        Console.WriteLine("Area of Circle: " + circle.Area());
       
        Console.ReadLine();
    }
}
